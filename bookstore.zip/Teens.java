import java.util.Scanner;

public class Teens {

    public static void teens() {
        Scanner scanner = new Scanner(System.in);
        int teens_book= 0; 
        boolean looper = true;
        while (looper ) {
			System.out.println(" ");
			System.out.println("++++++++++++++++++++++++++++++++++++++++++");
			System.out.println("               TEENS GENRE");
			System.out.println("++++++++++++++++++++++++++++++++++++++++++");
			System.out.println("              1 - FANTASY");
			System.out.println("              2 - SCI-FI");
			System.out.println("              3 - HORROR");
			System.out.println("              4 - MYSTERY");
			System.out.println("              5 - BACK");
			System.out.println("              6 - EXIT");

			System.out.print("              CHOOSE YOUR BOOK: ");
        
                teens_book = scanner.nextInt();
                switch (teens_book){
                    case 1: Teens_Fantasy();
                    break;
                    case 2: Teens_SciFi();
                    break;
                    case 3: Teens_Horror();
                    break;
                    case 4: Teens_Mystery();
                    break;
                    case 5: looper = false;
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    looper = true;
                    break;
                }
            }
        
    }

    // books for Teens 
    private static void Teens_Fantasy() 
    {
        Scanner scanner = new Scanner(System.in);
        int fantasy = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               TEENS CATEGORY");
        System.out.println("               FANTASY BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - Harry Potter 1");
        System.out.println("              2 - Percy Jackson Adventures");
        System.out.println("              3 - King of the Lava");
        System.out.println("              4 - Aswang Chronicles: Killer Man");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        fantasy = scanner.nextInt();

        switch (fantasy){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  Harry Potter 1  ");
                            System.out.println(" \n   Cost: Php. 1000.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: FANTASY   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.teensFantasyPayment(fantasy);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Percy Jackson Adventures  ");
                            System.out.println(" \n   Cost: Php. 290.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: FANTASY   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.teensFantasyPayment(fantasy); 
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: King of the Lava ");
                            System.out.println(" \n   Cost: Php. 399.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: FANTASY   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.teensFantasyPayment(fantasy); 
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Aswang Chronicles: Killer Man ");
                            System.out.println(" \n   Cost: Php. 120.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: FANTASY   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.teensFantasyPayment(fantasy); 
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }

    private static void Teens_SciFi() 
    {
        Scanner scanner = new Scanner(System.in);
        int sc = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               TEENS CATEGORY");
        System.out.println("               SCI-FI BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - Aliens");
        System.out.println("              2 - Space Pirates");
        System.out.println("              3 - Killer Dog ");
        System.out.println("              4 - Demon Space Monster");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        sc = scanner.nextInt();

        switch (sc){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  Aliens  ");
                            System.out.println(" \n   Cost: Php. 1000.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: SCI-FI   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.teensSciFiPayment(sc);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Space Pirates  ");
                            System.out.println(" \n   Cost: Php. 290.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: SCI-FI   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.teensSciFiPayment(sc); 
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:Killer Dog ");
                            System.out.println(" \n   Cost: Php. 399.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: SCI-FI   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.teensSciFiPayment(sc);
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Demon Space Monster ");
                            System.out.println(" \n   Cost: Php. 120.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: SCI-FI   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.teensSciFiPayment(sc);
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }
    private static void Teens_Horror() 
    {
        Scanner scanner = new Scanner(System.in);
        int h = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               TEENS CATEGORY");
        System.out.println("               HORROR BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - Shadows of the Demons");
        System.out.println("              2 - The Scary Doll");
        System.out.println("              3 - Dont Open your Eyes ");
        System.out.println("              4 - The 7th Sense");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        h = scanner.nextInt();

        switch (h){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  Shadows of the Demons  ");
                            System.out.println(" \n   Cost: Php. 100.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: HORROR   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.teensHorrorPayment(h);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: The Scary Doll  ");
                            System.out.println(" \n   Cost: Php. 290.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: HORROR   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.teensHorrorPayment(h);
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:Dont Open your Eyes ");
                            System.out.println(" \n   Cost: Php. 399.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: HORROR   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.teensHorrorPayment(h);
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: The 7th Sense ");
                            System.out.println(" \n   Cost: Php. 120.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: HORROR   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.teensHorrorPayment(h);
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }

    private static void Teens_Mystery() 
    {
        Scanner scanner = new Scanner(System.in);
        int m = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               TEENS CATEGORY");
        System.out.println("               MYSTERY BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - THE Death of the Minister");
        System.out.println("              2 - Who is the Killer?");
        System.out.println("              3 - Im alive, Where am I?");
        System.out.println("              4 - Mr. John Doe's Death");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        m = scanner.nextInt();

        switch (m){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  THE Death of the Minister  ");
                            System.out.println(" \n   Cost: Php. 1000.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: MYSTERY   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.teensMysteryPayment(m);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Who is the Killer?  ");
                            System.out.println(" \n   Cost: Php. 290.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: MYSTERY   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.teensMysteryPayment(m);
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Im alive, Where am I? ");
                            System.out.println(" \n   Cost: Php. 399.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: MYSTERY   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.teensMysteryPayment(m);
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Mr. John Doe's Death ");
                            System.out.println(" \n   Cost: Php. 120.00  ");
                            System.out.println(" \n   Genre: TEENS   ");
                            System.out.println(" \n   Type: MYSTERY   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.teensMysteryPayment(m);
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }
}

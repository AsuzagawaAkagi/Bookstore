import java.util.*;

public class bookstore {

    public static void printMenu() {
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               BOOK STORE");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("                  Genre");

        
        System.out.println("              1 - KIDS");
        System.out.println("              2 - TEENS");
        System.out.println("              3 - ADULTS");
        System.out.println("              4 - EXIT");
        System.out.print("              CHOOSE YOUR GENRE: ");

    }

    public static void main(String[] args) {
		Adults adultsObj = new Adults();
		Kids kidsObj = new Kids();
		Teens teensObj = new Teens();

        Scanner scanner = new Scanner(System.in);
        int option = 0;

        while (option != 4) {

            printMenu();
                option = scanner.nextInt();
                switch (option) {
                    case 1:
						kidsObj.kids();
					break;

                    case 2: 
						teensObj.teens();
					break;

                    case 3:
						adultsObj.adults();
					break;

                    case 4:
						System.exit(0);
                    default:
						System.out.println(" \n   Please Enter a number from 1 - 4 only.");
                    break;
                }
            
            
        }
    }
}
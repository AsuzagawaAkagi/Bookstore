import java.util.Scanner;
public class Adults {
    public static void adults() {
        Scanner scanner = new Scanner(System.in);
        int adults_book= 0; 
        boolean looper = true;
        while (looper ) {
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               ADULTS GENRE");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("              1 - ROMANCE");
        System.out.println("              2 - EROTIC");
        System.out.println("              3 - DIARIES");
        System.out.println("              4 - HISTORICAL BOOKS");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        
			adults_book = scanner.nextInt();
			switch (adults_book){
				case 1: Adults_Romance();
				break;
				case 2: Adults_Erotic();
				break;
				case 3: Adults_Diaries();
				break;
				case 4: Adults_History();
				break;
				case 5: looper = false;
				break;
				case 6: System.exit(0);
				break;
				default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
				looper = true;
				break;
			}
        }    
    }

    private static void Adults_Romance() 
    {
        Scanner scanner = new Scanner(System.in);
        int rms = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               ADULTS CATEGORY");
        System.out.println("               ROMANCE BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - Love is in the Air");
        System.out.println("              2 - Got 2 Believe ");
        System.out.println("              3 - Heart of Mine");
        System.out.println("              4 - Hearts Day");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        rms = scanner.nextInt();

        switch (rms){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  Love is in the Air  ");
                            System.out.println(" \n   Cost: Php. 1000.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: ROMANCE   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.adultRomancePayment(rms);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Got 2 Believe  ");
                            System.out.println(" \n   Cost: Php. 290.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: ROMANCE   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.adultRomancePayment(rms);
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  Heart of Mine ");
                            System.out.println(" \n   Cost: Php. 399.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: ROMANCE   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.adultRomancePayment(rms);
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Hearts Day ");
                            System.out.println(" \n   Cost: Php. 120.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: ROMANCE   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.adultRomancePayment(rms);
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }
    private static void Adults_Erotic() 
    {
        Scanner scanner = new Scanner(System.in);
        int ero = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               ADULTS CATEGORY");
        System.out.println("               EROTIC BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - SEX in the City");
        System.out.println("              2 - 40 shades of BLack ");
        System.out.println("              3 - Heart of the Playboys");
        System.out.println("              4 - Kissed and Sex");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        ero = scanner.nextInt();

        switch (ero){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  SEX in the City  ");
                            System.out.println(" \n   Cost: Php. 1200.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: EROTIC   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.adultEroticPayment(ero);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: 40 shades of BLack  ");
                            System.out.println(" \n   Cost: Php. 299.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: EROTIC   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.adultEroticPayment(ero);
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  Heart of the Playboys");
                            System.out.println(" \n   Cost: Php. 499.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: EROTIC   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.adultEroticPayment(ero);
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Kissed and Sex ");
                            System.out.println(" \n   Cost: Php. 1200.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: EROTIC   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.adultEroticPayment(ero);
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }
    private static void Adults_Diaries() 
    {
        Scanner scanner = new Scanner(System.in);
        int ero = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               ADULTS CATEGORY");
        System.out.println("               DIARIES BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - The Story of Kiko");
        System.out.println("              2 - Princess Diaries ");
        System.out.println("              3 - Kings Note to the World");
        System.out.println("              4 - Goodbye Mars");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        ero = scanner.nextInt();

        switch (ero){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  The Story of Kiko  ");
                            System.out.println(" \n   Cost: Php. 1200.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: DIARIES   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.adultDiariesPayment(ero);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Princess Diaries  ");
                            System.out.println(" \n   Cost: Php. 299.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: DIARIES   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  Kings Note to the World");
                            System.out.println(" \n   Cost: Php. 499.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: DIARIES   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Goodbye Mars ");
                            System.out.println(" \n   Cost: Php. 1200.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: DIARIES   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }

private static void Adults_History() 
    {
        Scanner scanner = new Scanner(System.in);
        int ero = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               ADULTS CATEGORY");
        System.out.println("               History BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - The Battle of Tirad Pass");
        System.out.println("              2 - I Shall return   ");
        System.out.println("              3 - Salute to the World");
        System.out.println("              4 - General Mc Arthur");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        ero = scanner.nextInt();

        switch (ero){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title:  The Battle of Tirad Pass  ");
                            System.out.println(" \n   Cost: Php. 1200.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: History   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
							Payment.adultHistoricalPayment(ero);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: I Shall return  ");
                            System.out.println(" \n   Cost: Php. 299.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: History   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.adultHistoricalPayment(ero);
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Salute to the World");
                            System.out.println(" \n   Cost: Php. 499.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: History   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.adultHistoricalPayment(ero);
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: General Mc Arthur ");
                            System.out.println(" \n   Cost: Php. 1200.00  ");
                            System.out.println(" \n   Genre: ADULTS   ");
                            System.out.println(" \n   Type: History   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
							Payment.adultHistoricalPayment(ero);
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }
}

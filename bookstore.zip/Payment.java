import java.util.Scanner;

public class Payment {
    
    static Scanner input = new Scanner(System.in);

    private static void paymentHandler(int amount) {
        int money = 0;
        System.out.print("   Please enter payment: ");
        money = input.nextInt();

        while(money < amount) {
            System.out.println("Not enough balance");
        }

        if(money > amount) {
            System.out.println("   Your change is: " + (money - amount));
            System.out.println("   Thanks for purchasing books with us");
        } else if (money == amount) {
            System.out.println("   Thanks for purchasing books with us");
        }
    
    }

    // ===== KIDS PAYMENT SECTION ===== //
    public static void kidsNurseryPayment(int choice) {
        if(choice == 1) { // Title: The Baby Singing
            paymentHandler(100);
        } else if (choice == 2) { // Title: Twinkle Stars
            paymentHandler(90);
        } else if (choice == 3) { //Title: Humpty Dunpty Fell
            paymentHandler(99);
        } else if (choice == 4) { // Title: Coco melon Adventures
            paymentHandler(120);
        }
    }

    public static void kidsFictionPayment(int choice) {
        if(choice == 1) { // Title: The Baby With Powers
            paymentHandler(150);
        } else if (choice == 2) { // Title: Twinkle Stars and the robots
            paymentHandler(99);
        } else if (choice == 3) { // Title: Humpty Dunpty Fell and lived
            paymentHandler(199);
        } else if (choice == 4) { // Title: Coco melon Adventures with Batman
            paymentHandler(180);
        }
    }

    public static void kidsFairytalePayment(int choice) {
        if(choice == 1) { // Title: The Fairy and the fish
            paymentHandler(150);
        } else if (choice == 2) { // Title: Magical Pants of Power Wizards
            paymentHandler(99);
        } else if (choice == 3) { // Title: Teleporting Elf
            paymentHandler(199);
        } else if (choice == 4) { //  Title: Magic Rings of Land of Oz
            paymentHandler(180);
        }
    }

    public static void kidsChildrensBookPayment(int choice) {
        if(choice == 1) { // Title: RED Riding Hood
            paymentHandler(150);
        } else if (choice == 2) { // Title: Wizard of Oz
            paymentHandler(99);
        } else if (choice == 3) { // Title: Dora the Singing Latina
            paymentHandler(199);
        } else if (choice == 4) { // Title: Three Little Pigs
            paymentHandler(180);
        }
    }
    // ===== END OF KIDS PAYMENT SECTION ===== //


    // ===== TEENS PAYMENT SECTION ===== //
    public static void teensFantasyPayment(int choice) {
        if(choice == 1) { // Title:  Harry Potter 1
            paymentHandler(1000);
        } else if (choice == 2) { // Title: Percy Jackson Adventures
            paymentHandler(290);
        } else if (choice == 3) { // Title: King of the Lava
            paymentHandler(399);
        } else if (choice == 4) { // Title: Aswang Chronicles: Killer Man
            paymentHandler(120);
        }
    }

    public static void teensSciFiPayment(int choice) {
        if(choice == 1) { // Title:  Aliens
            paymentHandler(1000);
        } else if (choice == 2) { // Title: Space Pirates
            paymentHandler(290);
        } else if (choice == 3) { // Title:Killer Dog
            paymentHandler(399);
        } else if (choice == 4) { // Title: Demon Space Monster
            paymentHandler(120);
        }
    }

    public static void teensHorrorPayment(int choice) {
        if(choice == 1) { // Title:  Shadows of the Demons
            paymentHandler(100);
        } else if (choice == 2) { // Title: The Scary Doll
            paymentHandler(290);
        } else if (choice == 3) { // Title:Dont Open your Eyes
            paymentHandler(399);
        } else if (choice == 4) { // Title: The 7th Sense
            paymentHandler(120);
        }
    }

    public static void teensMysteryPayment(int choice) {
        if(choice == 1) { // Title:  THE Death of the Minister
            paymentHandler(1000);
        } else if (choice == 2) { // Title: Who is the Killer?
            paymentHandler(290);
        } else if (choice == 3) { // Title: Im alive, Where am I?
            paymentHandler(399);
        } else if (choice == 4) { // Title: Mr. John Doe's Death
            paymentHandler(120);
        }
    }
    // ===== END OF TEENS PAYMENT SECTION ===== //

    // ===== ADULTS PAYMENT SECTION ===== //
    public static void adultRomancePayment(int choice) {
        if(choice == 1) { // Title:  Love is in the Air
            paymentHandler(1000);
        } else if (choice == 2) { // Title: Got 2 Believe
            paymentHandler(290);
        } else if (choice == 3) { // Title:  Heart of Mine
            paymentHandler(399);
        } else if (choice == 4) { // Title: Hearts Day
            paymentHandler(120);
        }
    }

    public static void adultEroticPayment(int choice) {
        if(choice == 1) { // Title:  SEX in the City
            paymentHandler(1200);
        } else if (choice == 2) { // Title: 40 shades of BLack
            paymentHandler(299);
        } else if (choice == 3) { // Title:  Heart of the Playboys
            paymentHandler(499);
        } else if (choice == 4) { // Title: Kissed and Sex
            paymentHandler(1200);
        }
    }

    public static void adultDiariesPayment(int choice) {
        if(choice == 1) { // Title:  The Story of Kiko
            paymentHandler(1200);
        } else if (choice == 2) { // Title: Princess Diaries
            paymentHandler(299);
        } else if (choice == 3) { // Title:  Kings Note to the World
            paymentHandler(499);
        } else if (choice == 4) { // Title: Goodbye Mars
            paymentHandler(1200);
        }
    }

    public static void adultHistoricalPayment(int choice) {
        if(choice == 1) { // Title:  The Battle of Tirad Pass
            paymentHandler(1200);
        } else if (choice == 2) { // Title: I Shall return
            paymentHandler(299);
        } else if (choice == 3) { // Title: Salute to the World
            paymentHandler(499);
        } else if (choice == 4) { // Title: General Mc Arthur
            paymentHandler(1200);
        }
    }
    // ===== END OF ADULTS PAYMENT SECTION ===== //

}

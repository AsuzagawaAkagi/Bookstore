import java.util.Scanner;

public class Kids {
    public static void kids() {
        Scanner scanner = new Scanner(System.in);
        int kids_book= 0; 
        boolean looper = true;
        while (looper )
            {
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               KIDS GENRE");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("              1 - NURSERY");
        System.out.println("              2 - FICTION");
        System.out.println("              3 - FAIRY TALE");
        System.out.println("              4 - CHILDRENS BOOK");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        
                kids_book = scanner.nextInt();
                switch (kids_book){
                    case 1: Kids_Nursery();
                    break;
                    case 2: Kids_Fiction(); 
                    break;
                    case 3: Kids_Fairytale();
                    break;
                    case 4: Kids_Child();
                    break;
                    case 5: looper = false;
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    looper = true;
                    break;
                }
            }
            

        
    }
    // books for KIDS 
    private static void Kids_Nursery() 
    {
        Scanner scanner = new Scanner(System.in);
        int nursery = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               KIDS CATEGORY");
        System.out.println("               NURSERY BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - The Baby Singing");
        System.out.println("              2 - Twinkle Stars");
        System.out.println("              3 - Humpty Dunpty Fell");
        System.out.println("              4 - Coco melon Adventures");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        nursery = scanner.nextInt();

        switch (nursery){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: The Baby Singing  ");
                            System.out.println(" \n   Cost: Php. 100.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Nursery   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsNurseryPayment(nursery);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Twinkle Stars  ");
                            System.out.println(" \n   Cost: Php. 90.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Nursery   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsNurseryPayment(nursery); 
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Humpty Dunpty Fell ");
                            System.out.println(" \n   Cost: Php. 99.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Nursery   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsNurseryPayment(nursery); 
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Coco melon Adventures ");
                            System.out.println(" \n   Cost: Php. 120.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Nursery   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsNurseryPayment(nursery); 
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;


                }



    }

    private static void Kids_Fiction() 
    {
        Scanner scanner = new Scanner(System.in);
        int fiction = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               KIDS CATEGORY");
        System.out.println("               FICTION BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - The Baby With Powers");
        System.out.println("              2 - Twinkle Stars and the robots");
        System.out.println("              3 - Humpty Dunpty Fell and lived");
        System.out.println("              4 - Coco melon Adventures with Batman");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        fiction = scanner.nextInt();

        switch (fiction){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: The Baby With Powers  ");
                            System.out.println(" \n   Cost: Php. 150.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Fiction   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsFictionPayment(fiction);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Twinkle Stars and the robots  ");
                            System.out.println(" \n   Cost: Php. 99.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Fiction   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
                            Payment.kidsFictionPayment(fiction);
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Humpty Dunpty Fell and lived ");
                            System.out.println(" \n   Cost: Php. 199.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Fiction   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsFictionPayment(fiction); 
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Coco melon Adventures with Batman ");
                            System.out.println(" \n   Cost: Php. 180.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Fiction   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsFictionPayment(fiction); 
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }
    private static void Kids_Fairytale() 
    {
        Scanner scanner = new Scanner(System.in);
        int ft = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               KIDS CATEGORY");
        System.out.println("               FAIRYTALE BOOKS");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - The Fairy and the fish");
        System.out.println("              2 - Magical Pants of Power Wizards");
        System.out.println("              3 - Teleporting Elf");
        System.out.println("              4 - Magic Rings of Land of Oz");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        ft = scanner.nextInt();

        switch (ft){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: The Fairy and the fish  ");
                            System.out.println(" \n   Cost: Php. 150.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Fairy Tales   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsFairytalePayment(ft);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Magical Pants of Power Wizards  ");
                            System.out.println(" \n   Cost: Php. 99.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Fairy Tales    ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsFairytalePayment(ft); 
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Teleporting Elf ");
                            System.out.println(" \n   Cost: Php. 199.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Fairy Tales    ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsFairytalePayment(ft); 
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Magic Rings of Land of Oz ");
                            System.out.println(" \n   Cost: Php. 180.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Fairy Tales    ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsFairytalePayment(ft); 
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }

    private static void Kids_Child() 
    {
        Scanner scanner = new Scanner(System.in);
        int cd = 0;
        System.out.println(" ");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("               KIDS CATEGORY");
        System.out.println("               CHILDRENS BOOK");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++");

        System.out.println("              1 - RED Riding Hood");
        System.out.println("              2 - Wizard of Oz");
        System.out.println("              3 - Dora the Singing Latina");
        System.out.println("              4 - Three Little Pigs");
        System.out.println("              5 - BACK");
        System.out.println("              6 - EXIT");

        System.out.print("              CHOOSE YOUR BOOK: ");
        cd = scanner.nextInt();

        switch (cd){
                    case 1: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: RED Riding Hood  ");
                            System.out.println(" \n   Cost: Php. 150.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Childrens Book   ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            Payment.kidsChildrensBookPayment(cd);
                            break;

                    case 2: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Wizard of Oz  ");
                            System.out.println(" \n   Cost: Php. 99.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Childrens Book    ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
                            Payment.kidsChildrensBookPayment(cd);
                            break;
                    case 3: System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Dora the Singing Latina ");
                            System.out.println(" \n   Cost: Php. 199.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Childrens Book    ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
                            Payment.kidsChildrensBookPayment(cd);
                            break;
                    case 4:  System.out.println("++++++++++++++++++++++++++++++++++++++++++");
                            System.out.println(" \n   Title: Three Little Pigs ");
                            System.out.println(" \n   Cost: Php. 180.00  ");
                            System.out.println(" \n   Genre: Kids   ");
                            System.out.println(" \n   Type: Childrens Book    ");
                            System.out.println("++++++++++++++++++++++++++++++++++++++++++"); 
                            Payment.kidsChildrensBookPayment(cd);
                            break;
                    case 5: 
                    break;
                    case 6: System.exit(0);
                    break;
                    default: System.out.println(" \n   Please Enter a number from 1 - 6 only.");
                    break;

                }



    }
}
